# League of Lasers Server

[![Build Status](https://travis-ci.com/nielsdebruin/LeagueOfLasersServer.svg?branch=master)](https://travis-ci.com/nielsdebruin/LeagueOfLasersServer)
[![Go Report Card](https://goreportcard.com/badge/github.com/nielsdebruin/LeagueOfLasersServer)](https://goreportcard.com/report/github.com/nielsdebruin/LeagueOfLasersServer)

Very basic server used to share Microsoft HoloLens anchors between HoloLenses.

